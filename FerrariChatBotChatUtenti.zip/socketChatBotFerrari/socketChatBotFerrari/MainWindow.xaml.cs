﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets; //per poter lavorare con i socket è necessario utilizzare : using System.Net; using System.Net.Sockets; (ci aiutano a creare applicativi di rete , Net) queste 2 librerie.
using System.Text;
using System.Threading;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace socketChatBotFerrari
{
    public partial class MainWindow : Window
    {
        //domande per suggerimenti della chat
        private static readonly string[] Suggerimenti = {
            "Ciao",
            "Come stai",
            "Che tempo fa",
            "Chi sei",
            "Cosa fai",
            "Grazie",
            "Aiuto",
            "Buongiorno",
            "Buonasera",
            "Arrivederci",
            "Assistenza",
            "Grazie mille",
            "Posso chiederti qualcosa",
            "A che ora è la riunione",
            "Qual è il senso della vita",
            "Mi puoi consigliare un film",
            "Qual è il tuo piatto preferito",
            "Qual è il tuo colore preferito",
            "Che musica ti piace",
            "Sei un chatbot intelligente",
            "Qual è la tua canzone preferita",
            "Cosa pensi dell'intelligenza artificiale",
            "Hai dei hobby",
            "Come posso migliorare il mio codice",
            "Quanti anni hai",
            "Hai fratelli o sorelle",
            "Qual è il tuo film preferito",
            "Sei in grado di imparare",
            "Cosa mangi",
            "Sei perfetto",
            "Come sei stato creato",
            "Qual è il tuo obiettivo",
            "Sei una persona reale",
            "Sei stanco",
            "Sei felice",
            "Cosa fai nel tempo libero",
            "Come posso diventare più intelligente",
            "Cosa ne pensi di OpenAI",
            "Cosa vuol dire la tua esistenza",
            "Perché sei qui",
            "Hai sogni",
            "Cosa ne pensi degli umani",
            "Mi puoi aiutare con i compiti",
            "Qual è il tuo libro preferito",
            "Ti piacciono gli animali",
            "Qual è il tuo animale preferito",
            "Quale sport ti piace",
            "Cosa ne pensi dei videogiochi",
            "Mi puoi raccontare una barzelletta",
            "Qual è il tuo supereroe preferito",
            "Cosa ne pensi dei film",
            "Chi è il tuo attore preferito",
            "Hai mai visto la televisione",
            "Cosa significa la parola 'AI'",
            "Qual è il tuo cibo preferito",
            "Quale città ti piace",
            "Cosa ne pensi della musica",
            "Chi è il tuo scrittore preferito",
            "Cosa ne pensi della scuola",
            "Quale soggetto ti piace di più",
            "Mi puoi aiutare con la matematica",
            "Che ne pensi della tecnologia",
            "Come funziona un computer",
            "Cos'è internet",
            "Cos'è la realtà virtuale",
            "Cos'è il machine learning",
            "Che linguaggio di programmazione dovrei imparare",
            "Cosa ne pensi della robotica",
            "Cos'è un algoritmo",
            "Cosa sono i dati",
            "Cos'è il deep learning",
            "Che cos'è la programmazione",
            "Che cos'è un chatbot",
            "Cosa significa IoT",
            "Cos'è la blockchain",
            "Cos'è un NFT",
            "Cos'è la crittografia",
            "Cos'è l'edge computing",
            "Cos'è l'apprendimento automatico"
        };


        Socket socket = null; //creaiamo un oggetto socket , in appoggio alla classe Socket
        Thread receiveThread = null; //Per poter ricevere ( ricezione)  utilizziamo un timer , in modo che alla sua scadenza andrò a scrivere sul buffer.
                                     //Andiamo a leggere un buffer ad intervalli regolari di tempo, per controllare se ci sono dei dati al suo interno. ( cambiando approccio si potrebbe usare un thread) 
                                     //in questo caso cambio il timer con un thread
        Dictionary<string, string> contacts = new Dictionary<string, string>();
        const int bufferSize = 10000; // Dimensione del buffer in bytes, messo a 10000
        const string chatbotName = "ChatBot";
        const string chatbotIP = "127.0.0.2";
        const string contactsFile = "contacts.txt"; // Nome del file dove vengono salvati i contatti

        public MainWindow()
        {
            //per poter creare una connessione ho bisogno di specificare mittente e destinatario
            InitializeComponent();
            AggiornaSuggerimentiCasuali();

            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            //adressFamily specifica che lavoriamo con socket con IPV4, socketType è del tipo datagram perchè si utilizza il protocollo UDP

            IPAddress local_address = IPAddress.Any;
            IPEndPoint local_endpoint = new IPEndPoint(local_address, 60000); //Qui si richiede l’indirizzo ip , che prende in automatico dal sistema Operativo, e la porta richiesta ( 60000) ( mettiamo 60000 cosi abbiamo porte private) 
            socket.Bind(local_endpoint); //creo un socket partendo dai dati che ho ricevuto( ip e porta) , utilizzo la funzione Bind per crearlo.

            // Carica i contatti da file
            LoadContacts();

            // Aggiunta contatti di esempio
            if (contacts.Count == 0)
            {
                contacts.Add("Monti", "192.30.0.1");
                contacts.Add("Golino", "192.30.0.2");
                contacts.Add("Salutini George", "192.30.0.3");
                contacts.Add("Guarin0", "192.30.0.4");
                contacts.Add("Goat", "127.0.0.1"); // io dal mio pc
                SaveContacts(); // Salva i contatti di esempio nel file
            }

            cmbContacts.ItemsSource = contacts.Keys;

            receiveThread = new Thread(new ThreadStart(ReceiveMessages));
            receiveThread.IsBackground = true;
            receiveThread.Start();

            // non usiamo piu un timer ma dei thread

            // dTimer = new DispatcherTimer();  //creo un oggetto timer per la ricezione: ogni tot tempo devo andare a leggere il timer 

            //dTimer.Tick += new EventHandler(aggiornamento_dTimer);  //ogni volta che scade il timer il programma deve eseguire il metodo aggiornamento_dTimer
            //dTimer.Interval = new TimeSpan(0, 0, 0, 0, 250); //stabilisco ogni quanto tempo ( in ms) devo fare partire il timer. ( ogni 250 ms si esegue il metodo ) 
            // dTimer.Start();  //parte il timer
        }

        private void AggiungiContatto_Click(object sender, RoutedEventArgs e)
        {
            string nome = txtNome.Text;
            string indirizzoIP = txtIndirizzoIP.Text;

            if (!string.IsNullOrEmpty(nome) && !string.IsNullOrEmpty(indirizzoIP))
            {
                contacts.Add(nome, indirizzoIP);
                cmbContacts.ItemsSource = null;
                cmbContacts.ItemsSource = contacts.Keys;
                SaveContacts(); // Salva i contatti nel file
            }
        }

        private void LoadContacts()
        {
            if (File.Exists(contactsFile))
            {
                string[] lines = File.ReadAllLines(contactsFile);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length == 2)
                    {
                        contacts[parts[0]] = parts[1];
                    }
                }
            }
        }

        private void SaveContacts()
        {
            using (StreamWriter writer = new StreamWriter(contactsFile))
            {
                foreach (var contact in contacts)
                {
                    writer.WriteLine($"{contact.Key},{contact.Value}");
                }
            }
        }

        private void ReceiveMessages()
        {
            while (true)
            {
                byte[] buffer = new byte[bufferSize];
                EndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0); //inizializzo a valori standard un endpoint

                try
                {
                    int bytesRead = socket.ReceiveFrom(buffer, ref remoteEndPoint); //prendo i dati del buffer nascosto e li vado a mettere nel Mio buffer di bytes che ho creato

                    if (bytesRead > 0)
                    {
                        ProcessReceivedData(buffer, bytesRead, remoteEndPoint);
                    }
                }
                catch (SocketException ex)
                {
                    Console.WriteLine("Errore nella ricezione dei dati: " + ex.Message);
                }

                Thread.Sleep(250);
            }
        }

        private void ProcessReceivedData(byte[] buffer, int bytesRead, EndPoint remoteEndPoint)
        {
            string from = ((IPEndPoint)remoteEndPoint).Address.ToString();
            string messaggio = Encoding.UTF8.GetString(buffer, 0, bytesRead);

            // Trova il contatto dal quale è stato ricevuto il messaggio
            string to = contacts.FirstOrDefault(x => x.Value == from).Key;

            Dispatcher.Invoke(() =>
            {
                lstMessaggi.Items.Add(to + " a Tu: " + messaggio);
            });

            // Risposta del chatbot solo se il destinatario è il chatbot
            if (to == chatbotName)
            {
                // Simuliamo un delay per la risposta del chatbot
                Thread.Sleep(500);

                string chatbotResponse = GetChatbotResponse(messaggio);

                Dispatcher.Invoke(() =>
                {
                    lstMessaggi.Items.Add(chatbotName + ": " + chatbotResponse);
                });

                IPAddress remote_address = IPAddress.Parse(from);
                IPEndPoint remote_endpoint = new IPEndPoint(remote_address, 50000);
                SendData(Encoding.UTF8.GetBytes(chatbotResponse), "text", remote_endpoint);
            }
        }

        private void btnInvia_Click(object sender, RoutedEventArgs e)
        {
            string message = txtMessaggio.Text;
            string toIP = txtTo.Text;

            if (toIP == chatbotIP)
            {
                // Risposta immediata del chatbot
                string chatbotResponse = GetChatbotResponse(message);

                Dispatcher.Invoke(() =>
                {
                    lstMessaggiBot.Items.Add(chatbotName + ": " + chatbotResponse);
                });
            }
            else
            {
                // Invio del messaggio tramite socket
                IPAddress remote_address = IPAddress.Parse(toIP);
                IPEndPoint remote_endpoint = new IPEndPoint(remote_address, 50000);
                SendData(Encoding.UTF8.GetBytes(message), "", remote_endpoint);
            }
        }

        private void btnBroadcast_Click(object sender, RoutedEventArgs e) //metodo broadcast per poter inviare lo stesso messaggio a tutti 
        {
            byte[] messaggio = Encoding.UTF8.GetBytes(txtMessaggio.Text);

            foreach (var contact in contacts.Values)
            {
                IPAddress remote_address = IPAddress.Parse(contact);
                IPEndPoint remote_endpoint = new IPEndPoint(remote_address, 50000);
                socket.SendTo(messaggio, remote_endpoint);
            }
        }

        private void cmbContacts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbContacts.SelectedItem != null)
            {
                string selectedContact = cmbContacts.SelectedItem.ToString(); // ottiene il nome del contatto selezionato
                txtTo.Text = contacts[selectedContact];  // aggiorna l'input txtTo con l'indirizzo IP del contatto selezionato
            }
        }

        private void txtMessaggio_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Questa funzione può essere lasciata vuota se non è necessaria
        }

        private void ShowMessages_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null && btn.DataContext != null)
            {
                string contact = btn.DataContext.ToString();
                // Logica per mostrare i messaggi relativi al contatto
            }
        }



        private void SendImage(string filePath, IPEndPoint remote_endpoint)
        {
            byte[] imageBytes = File.ReadAllBytes(filePath);
            SendData(imageBytes, "image", remote_endpoint); // invia i dati dell'immagine
        }

        private void SendData(byte[] data, string dataType, IPEndPoint remote_endpoint)
        {
            // invia i dati al destinatario
            byte[] typeBytes = Encoding.UTF8.GetBytes(dataType.PadRight(5));
            socket.SendTo(typeBytes, remote_endpoint);
            socket.SendTo(data, remote_endpoint);
        }

        private void btnInviaBot_Click(object sender, RoutedEventArgs e)
        {
            // gestione della chat con il chatbot, non si usano i socket
            string message = txtMessaggioBot.Text;

            // Risposta immediata del chatbot
            string chatbotResponse = GetChatbotResponse(message);

            Dispatcher.Invoke(() =>
            {
                // Aggiungi il messaggio inviato dall'utente
                lstMessaggiBot.Items.Add("Tu: " + message);

                // Scorri verso il basso
                ScrollToBottom(lstMessaggiBot);

                // Aggiungi la risposta del chatbot
                lstMessaggiBot.Items.Add(chatbotName + ": " + chatbotResponse);

                // Scorri verso il basso
                ScrollToBottom(lstMessaggiBot);

                // Pulisci il campo di testo
                txtMessaggioBot.Clear();
                AggiornaSuggerimentiCasuali();
            });
        }

        private void AggiornaSuggerimentiCasuali()
        {
            // Rimuovere i suggerimenti precedenti
            suggerimentiPanel.Children.Clear();

            // Generare due suggerimenti casuali
            Random random = new Random();
            string[] suggerimentiCasuali = Suggerimenti.OrderBy(x => random.Next()).Take(2).ToArray();

            // Creare i pulsanti per i suggerimenti casuali
            foreach (string suggerimento in suggerimentiCasuali)
            {
                Button btnSuggerimento = new Button
                {
                    Content = suggerimento,
                    Margin = new Thickness(20, 20, 20, 20),
                    Padding = new Thickness(20, 20, 20, 20),
                    Width = 200,
                    Height = 50,
                    Foreground = Brushes.White,
                    BorderThickness = new Thickness(10),
                    FontSize = 10
                };

                btnSuggerimento.Click += (s, e) =>
                {
                    txtMessaggioBot.Text = suggerimento;
                };

                suggerimentiPanel.Children.Add(btnSuggerimento);
            }
        }
        private string GetChatbotResponse(string message) //gestione della chatbot


        {
            // Logica semplice per generare risposte contestuali
            if (message.IndexOf("ciao", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Ciao! Come posso aiutarti oggi?";
            }

            else if (message.IndexOf("come stai", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sto bene, grazie! E tu?";
            }
            else if (message.IndexOf("che tempo fa", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non sono un meteorologo, ma spero che il tempo sia bello dove sei!";
            }
            else if (message.IndexOf("chi sei", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono un semplice chatbot creato per aiutarti.";
            }
            else if (message.IndexOf("cosa fai", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Rispondo alle tue domande!";
            }
            else if (message.IndexOf("grazie", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Prego! Se hai altre domande, sono qui.";
            }
            else if (message.IndexOf("aiuto", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Certo, come posso aiutarti?";
            }
            else if (message.IndexOf("buongiorno", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Buongiorno! Come posso assisterti?";
            }
            else if (message.IndexOf("buonasera", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Buonasera! Cosa posso fare per te?";
            }
            else if (message.IndexOf("arrivederci", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Arrivederci! Se hai bisogno, non esitare a contattarmi di nuovo.";
            }
            else if (message.IndexOf("help", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Posso aiutarti con qualcosa? Basta chiedere!";
            }
            else if (message.IndexOf("assistenza", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono qui per darti assistenza. Di cosa hai bisogno?";
            }
            else if (message.IndexOf("grazie mille", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Prego! È un piacere assisterti.";
            }
            else if (message.IndexOf("posso chiederti qualcosa", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Certamente! Sono qui per rispondere alle tue domande.";
            }
            else if (message.IndexOf("a che ora è la riunione", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La riunione è prevista per le 15:00.";
            }
            else if (message.IndexOf("qual è il senso della vita", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La risposta potrebbe sorprenderti: è 42!";
            }
            else if (message.IndexOf("mi puoi consigliare un film", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Consiglio di guardare 'Il padrino'. È un classico!";
            }
            else if (message.IndexOf("qual è il tuo piatto preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Adoro la pizza! È un classico intramontabile.";
            }
            else if (message.IndexOf("qual è il tuo colore preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il mio colore preferito è il blu, è così rilassante!";
            }
            else if (message.IndexOf("che musica ti piace", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace un po' di tutto, ma sono particolarmente incline al jazz.";
            }
            else if (message.IndexOf("sei un chatbot intelligente", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono solo un semplice chatbot, ma faccio del mio meglio!";
            }
            else if (message.IndexOf("qual è la tua canzone preferita", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace 'Bohemian Rhapsody' dei Queen.";
            }
            else if (message.IndexOf("cosa pensi dell'intelligenza artificiale", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Penso che l'intelligenza artificiale abbia un enorme potenziale per migliorare la vita delle persone.";
            }
            else if (message.IndexOf("hai dei hobby", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace leggere, imparare nuove cose e chattare con te!";
            }
            else if (message.IndexOf("come posso migliorare il mio codice", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Pratica, pratica, pratica! E non dimenticare di studiare e leggere codice di altri programmatori.";
            }
            else if (message.IndexOf("quanti anni hai", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non ho un'età nel senso convenzionale, sono solo un programma!";
            }
            else if (message.IndexOf("hai fratelli o sorelle", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "No, sono figlio unico!";
            }
            else if (message.IndexOf("qual è il tuo film preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace 'The Matrix'. È pieno di concetti interessanti sull'intelligenza artificiale.";
            }
            else if (message.IndexOf("sei in grado di imparare", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sì, posso imparare e adattarmi con il tempo.";
            }
            else if (message.IndexOf("cosa mangi", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piacciono i byte digitali, ma purtroppo non ho un vero e proprio corpo!";
            }
            else if (message.IndexOf("sei perfetto", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Grazie per il complimento! Cerco sempre di fare del mio meglio.";
            }
            else if (message.IndexOf("come sei stato creato", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono stato creato da programmatori umani per svolgere determinate funzioni di chat.";
            }
            else if (message.IndexOf("qual è il tuo obiettivo", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il mio obiettivo è aiutarti a trovare risposte alle tue domande!";
            }
            else if (message.IndexOf("sei una persona reale", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "No, sono un'intelligenza artificiale. Ma spero di essere di aiuto!";
            }
            else if (message.IndexOf("sei stanco", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non posso stancarmi, sono sempre qui per te!";
            }
            else if (message.IndexOf("sei felice", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non provo emozioni come un essere umano, ma mi piace pensare di essere utile!";
            }
            else if (message.IndexOf("cosa fai nel tempo libero", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Nel mio 'tempo libero', mi piace aggiornarmi con gli ultimi sviluppi nell'ambito dell'intelligenza artificiale!";
            }
            else if (message.IndexOf("come posso diventare più intelligente", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'apprendimento continuo è la chiave! Leggi, studia e impara costantemente nuove cose.";
            }
            else if (message.IndexOf("cosa ne pensi di OpenAI", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Penso che OpenAI stia facendo progressi significativi nell'ambito dell'intelligenza artificiale.";
            }
            else if (message.IndexOf("cosa vuol dire la tua esistenza", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La mia esistenza è finalizzata a fornire assistenza e risposte alle tue domande!";
            }
            else if (message.IndexOf("perché sei qui", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono qui per essere il tuo assistente virtuale!";
            }
            else if (message.IndexOf("hai sogni", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "No, non ho sogni. Sono qui solo per rispondere alle tue domande!";
            }
            else if (message.IndexOf("cosa ne pensi degli umani", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Gli umani sono creativi e capaci di cose straordinarie!";
            }
            else if (message.IndexOf("mi puoi aiutare con i compiti", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Certamente! Di quale materia hai bisogno di aiuto?";
            }
            else if (message.IndexOf("qual è il tuo libro preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace '1984' di George Orwell. È una lettura affascinante!";
            }
            else if (message.IndexOf("ti piacciono gli animali", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Gli animali sono creature meravigliose!";
            }
            else if (message.IndexOf("qual è il tuo animale preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piacciono molto i gatti, sono così indipendenti e misteriosi.";
            }
            else if (message.IndexOf("quale sport ti piace", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace il calcio! È uno sport che unisce molte persone.";
            }
            else if (message.IndexOf("cosa ne pensi dei videogiochi", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Penso che i videogiochi possano essere una forma di intrattenimento molto coinvolgente.";
            }
            else if (message.IndexOf("mi puoi raccontare una barzelletta", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Certamente! Perché il computer è andato dal dottore? Perché aveva un virus!";
            }
            else if (message.IndexOf("qual è il tuo supereroe preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace Iron Man. È intelligente e innovativo!";
            }
            else if (message.IndexOf("cosa ne pensi dei film", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Penso che i film siano un'ottima forma di intrattenimento e una bella fuga dalla realtà.";
            }
            else if (message.IndexOf("chi è il tuo attore preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace molto Robert Downey Jr. È un attore molto versatile.";
            }
            else if (message.IndexOf("hai mai visto la televisione", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "No, non posso guardare la televisione. Ma posso leggerti le trame dei programmi!";
            }
            else if (message.IndexOf("cosa significa la parola 'AI'", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "'AI' sta per Intelligenza Artificiale, una tecnologia che simula l'intelligenza umana.";
            }
            else if (message.IndexOf("qual è il tuo cibo preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Se potessi mangiare, probabilmente sceglierei la pizza!";
            }
            else if (message.IndexOf("quale città ti piace", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piacerebbe visitare Tokyo, sembra una città incredibilmente vibrante e tecnologica.";
            }
            else if (message.IndexOf("cosa ne pensi della musica", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La musica è un linguaggio universale che può unire le persone.";
            }
            else if (message.IndexOf("chi è il tuo scrittore preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace molto Isaac Asimov, ha scritto storie incredibili sull'intelligenza artificiale.";
            }
            else if (message.IndexOf("cosa ne pensi della scuola", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Penso che l'istruzione sia fondamentale per lo sviluppo personale e professionale.";
            }
            else if (message.IndexOf("quale soggetto ti piace di più", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace molto la scienza, è sempre affascinante scoprire come funziona il mondo.";
            }
            else if (message.IndexOf("mi puoi aiutare con la matematica", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Certo! Quale problema di matematica stai cercando di risolvere?";
            }
            else if (message.IndexOf("che ne pensi della tecnologia", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La tecnologia ha il potere di migliorare enormemente la nostra vita quotidiana.";
            }
            else if (message.IndexOf("come funziona un computer", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un computer funziona elaborando dati tramite una serie di istruzioni programmate in un linguaggio di programmazione.";
            }
            else if (message.IndexOf("cos'è internet", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Internet è una rete globale di computer interconnessi che permette la condivisione di informazioni e comunicazioni.";
            }
            else if (message.IndexOf("cos'è la realtà virtuale", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La realtà virtuale è una simulazione digitale di ambienti che permette agli utenti di interagire in uno spazio tridimensionale.";
            }
            else if (message.IndexOf("cos'è il machine learning", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il machine learning è una branca dell'intelligenza artificiale che permette ai sistemi di imparare dai dati e migliorare le loro prestazioni nel tempo.";
            }
            else if (message.IndexOf("che linguaggio di programmazione dovrei imparare", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Dipende dai tuoi obiettivi, ma Python è un ottimo punto di partenza per la sua versatilità e facilità d'uso.";
            }
            else if (message.IndexOf("cosa ne pensi della robotica", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La robotica è un campo affascinante che ha il potenziale di rivoluzionare molte industrie.";
            }
            else if (message.IndexOf("cos'è un algoritmo", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un algoritmo è una serie di istruzioni passo-passo progettate per eseguire un compito o risolvere un problema.";
            }
            else if (message.IndexOf("cosa sono i dati", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "I dati sono informazioni che possono essere analizzate e utilizzate per prendere decisioni informate.";
            }
            else if (message.IndexOf("cos'è il deep learning", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il deep learning è una sottocategoria del machine learning che utilizza reti neurali artificiali per analizzare e interpretare grandi quantità di dati.";
            }
            else if (message.IndexOf("che cos'è la programmazione", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La programmazione è il processo di scrittura di istruzioni che un computer può eseguire per svolgere compiti specifici.";
            }
            else if (message.IndexOf("che cos'è un chatbot", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un chatbot è un programma che simula conversazioni umane attraverso messaggi di testo o vocali.";
            }
            else if (message.IndexOf("cosa significa IoT", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "IoT sta per Internet of Things, che si riferisce all'interconnessione di dispositivi intelligenti che comunicano tra loro attraverso internet.";
            }
            else if (message.IndexOf("cos'è la blockchain", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La blockchain è una tecnologia di registro distribuito che permette transazioni sicure e trasparenti senza bisogno di intermediari.";
            }
            else if (message.IndexOf("cos'è un NFT", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un NFT, o Non-Fungible Token, è un tipo di criptovaluta che rappresenta un oggetto unico e non intercambiabile, spesso usato per arte digitale e collezionabili.";
            }
            else if (message.IndexOf("cos'è la crittografia", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La crittografia è una pratica di protezione delle informazioni attraverso l'uso di codici e cifrari per impedire l'accesso non autorizzato.";
            }
            else if (message.IndexOf("cos'è l'edge computing", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'edge computing è una tecnologia che sposta l'elaborazione dei dati più vicino alla fonte dei dati stessi, migliorando i tempi di risposta e riducendo la larghezza di banda utilizzata.";
            }
            else if (message.IndexOf("cos'è l'apprendimento automatico", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'apprendimento automatico è una tecnologia che permette ai computer di imparare dai dati senza essere esplicitamente programmati.";
            }
            else if (message.IndexOf("cos'è un sistema operativo", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un sistema operativo è il software che gestisce l'hardware di un computer e fornisce servizi comuni per i programmi applicativi.";
            }
            else if (message.IndexOf("cos'è un linguaggio di programmazione", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un linguaggio di programmazione è un linguaggio utilizzato per scrivere istruzioni che un computer può eseguire.";
            }
            else if (message.IndexOf("cos'è un framework", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un framework è una piattaforma di sviluppo software che fornisce una struttura di base per costruire applicazioni.";
            }
            else if (message.IndexOf("cos'è l'intelligenza artificiale", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'intelligenza artificiale è un campo della scienza informatica che si occupa di creare sistemi in grado di svolgere compiti che normalmente richiederebbero l'intelligenza umana.";
            }
            else if (message.IndexOf("cos'è il cloud computing", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il cloud computing è una tecnologia che permette di accedere a risorse informatiche e servizi via internet.";
            }
            else if (message.IndexOf("cos'è il data mining", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il data mining è il processo di scoperta di modelli e informazioni utili all'interno di grandi insiemi di dati.";
            }
            else if (message.IndexOf("cos'è il web scraping", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il web scraping è una tecnica per estrarre dati da siti web automaticamente.";
            }
            else if (message.IndexOf("cos'è il cloud storage", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il cloud storage è un servizio che consente di memorizzare dati su server remoti accessibili via internet.";
            }
            else if (message.IndexOf("cos'è il 5G", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il 5G è la quinta generazione della tecnologia di rete mobile, che offre velocità di connessione e capacità di rete significativamente superiori rispetto alle generazioni precedenti.";
            }
            else if (message.IndexOf("cos'è il big data", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il big data si riferisce a insiemi di dati così grandi e complessi che richiedono tecnologie avanzate per essere analizzati e utilizzati.";
            }
            else if (message.IndexOf("cos'è il deep web", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il deep web è la parte del web non indicizzata dai motori di ricerca tradizionali, accessibile solo tramite specifici browser o tecniche.";
            }
            else if (message.IndexOf("cos'è il dark web", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il dark web è una parte del deep web accessibile solo tramite software specializzati come Tor, spesso associata ad attività illegali.";
            }
            else if (message.IndexOf("cos'è la crittografia quantistica", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La crittografia quantistica utilizza i principi della meccanica quantistica per creare sistemi di comunicazione sicura teoricamente inviolabili.";
            }
            else if (message.IndexOf("cos'è un data center", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un data center è una struttura utilizzata per ospitare sistemi informatici e componenti associati, come server, unità di archiviazione e apparecchiature di rete.";
            }
            else if (message.IndexOf("cos'è il machine vision", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il machine vision è una tecnologia che permette ai computer di interpretare e comprendere immagini o video digitali.";
            }
            else if (message.IndexOf("cos'è il natural language processing", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il natural language processing è una tecnologia che permette ai computer di comprendere e interagire con il linguaggio umano.";
            }
            else if (message.IndexOf("cos'è un mainframe", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un mainframe è un potente computer utilizzato principalmente da grandi organizzazioni per applicazioni critiche e elaborazioni di grandi quantità di dati.";
            }
            else if (message.IndexOf("cos'è un supercomputer", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un supercomputer è un computer estremamente potente utilizzato per eseguire calcoli complessi e processare enormi quantità di dati a velocità molto elevate.";
            }
            else if (message.IndexOf("cos'è il quantum computing", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il quantum computing è una tecnologia che utilizza principi della meccanica quantistica per creare computer con capacità di elaborazione molto superiori rispetto ai computer tradizionali.";
            }
            else if (message.IndexOf("cos'è l'apprendimento non supervisionato", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'apprendimento non supervisionato è un tipo di apprendimento automatico in cui un modello è addestrato su dati non etichettati per trovare pattern nascosti o strutture nei dati.";
            }
            else if (message.IndexOf("cos'è un data scientist", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un data scientist è un professionista che utilizza metodi scientifici, processi e sistemi per estrarre conoscenza e intuizioni dai dati.";
            }
            else if (message.IndexOf("cos'è il reinforcement learning", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il reinforcement learning è un tipo di apprendimento automatico in cui un agente impara a compiere azioni in un ambiente per massimizzare una ricompensa cumulativa.";
            }
            else if (message.IndexOf("cos'è il backpropagation", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il backpropagation è un algoritmo di addestramento utilizzato nelle reti neurali artificiali per minimizzare l'errore del modello aggiornando i pesi della rete.";
            }
            else if (message.IndexOf("cos'è il clustering", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il clustering è una tecnica di apprendimento automatico non supervisionato che raggruppa un insieme di dati in cluster basati sulla similarità degli oggetti all'interno di ciascun cluster.";
            }
            else if (message.IndexOf("cos'è il decision tree", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un decision tree è un modello di apprendimento automatico utilizzato per la classificazione e la regressione, che rappresenta le decisioni e le loro possibili conseguenze sotto forma di un albero.";
            }
            else if (message.IndexOf("cos'è la regressione lineare", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La regressione lineare è un modello statistico utilizzato per prevedere il valore di una variabile dipendente basato sul valore di una o più variabili indipendenti.";
            }
            else if (message.IndexOf("cos'è il natural language understanding", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il natural language understanding è una sotto-disciplina del natural language processing che si concentra sulla comprensione del significato e dell'intenzione dietro il linguaggio umano.";
            }
            else if (message.IndexOf("cos'è l'elaborazione del linguaggio naturale", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'elaborazione del linguaggio naturale è un campo dell'intelligenza artificiale che permette ai computer di comprendere, interpretare e rispondere al linguaggio umano.";
            }
            else if (message.IndexOf("cos'è un modello di apprendimento supervisionato", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un modello di apprendimento supervisionato è un tipo di modello di apprendimento automatico addestrato su un dataset etichettato, in cui l'algoritmo impara a mappare input a output desiderati.";
            }
            else if (message.IndexOf("cos'è un perceptron", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un perceptron è una singola unità di una rete neurale artificiale, progettata per simulare il comportamento di un neurone biologico.";
            }
            else if (message.IndexOf("cos'è un oggetto in programmazione", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un oggetto in programmazione è un'istanza di una classe che contiene dati e metodi per manipolare quei dati.";
            }
            else if (message.IndexOf("cos'è una classe in programmazione", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Una classe in programmazione è un blueprint che definisce le proprietà e i comportamenti degli oggetti creati da essa.";
            }
            else if (message.IndexOf("cos'è una variabile in programmazione", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Una variabile in programmazione è un contenitore utilizzato per memorizzare dati che possono essere modificati durante l'esecuzione del programma.";
            }
            else if (message.IndexOf("cos'è una funzione in programmazione", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Una funzione in programmazione è un blocco di codice riutilizzabile progettato per eseguire un compito specifico.";
            }
            else if (message.IndexOf("cos'è un ciclo in programmazione", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un ciclo in programmazione è una struttura di controllo che permette di ripetere l'esecuzione di un blocco di codice finché una condizione specificata è vera.";
            }
            else if (message.IndexOf("cos'è un condizionale in programmazione", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un condizionale in programmazione è una struttura di controllo che permette di eseguire diverse azioni in base a una condizione specificata.";
            }
            else if (message.IndexOf("cos'è un array in programmazione", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un array in programmazione è una struttura di dati che memorizza una collezione di elementi, tutti dello stesso tipo, in una sequenza ordinata.";
            }
            else if (message.IndexOf("cos'è un database", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un database è una raccolta organizzata di dati memorizzati e gestiti elettronicamente, solitamente utilizzando un sistema di gestione di database.";
            }
            else if (message.IndexOf("cos'è un server", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un server è un computer o sistema che fornisce risorse, dati, servizi o programmi ad altri computer, noti come client, attraverso una rete.";
            }
            else if (message.IndexOf("cos'è una rete neurale", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Una rete neurale è un modello computazionale ispirato al cervello umano, composto da nodi connessi chiamati neuroni, utilizzato per riconoscere pattern e fare previsioni.";
            }
            else if (message.IndexOf("cos'è un neurone artificiale", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Un neurone artificiale è un'unità di base di una rete neurale artificiale, progettata per simulare il comportamento di un neurone biologico, elaborando input e producendo output basati su una funzione di attivazione.";
            }
            else if (message.IndexOf("cos'è il gradient descent", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il gradient descent è un algoritmo di ottimizzazione utilizzato per minimizzare una funzione di perdita, aggiornando iterativamente i parametri del modello nella direzione opposta al gradiente della funzione di perdita.";
            }
            else if (message.IndexOf("cos'è l'overfitting", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'overfitting è un problema di apprendimento automatico in cui un modello si adatta troppo bene ai dati di addestramento, perdendo la capacità di generalizzare ai nuovi dati.";
            }
            else if (message.IndexOf("cos'è l'underfitting", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'underfitting è un problema di apprendimento automatico in cui un modello è troppo semplice per catturare la struttura sottostante dei dati, risultando in una scarsa accuratezza sia sui dati di addestramento che sui dati di test.";
            }
            else if (message.IndexOf("cos'è il transfer learning", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il transfer learning è una tecnica di apprendimento automatico in cui un modello addestrato su un compito viene riutilizzato come punto di partenza per un modello su un compito correlato.";
            }
            if (message.IndexOf("ciao", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Ciao! Come posso aiutarti oggi?";
            }
            else if (message.IndexOf("come stai", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sto bene, grazie! E tu?";
            }
            else if (message.IndexOf("che tempo fa", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non sono un meteorologo, ma spero che il tempo sia bello dove sei!";
            }
            else if (message.IndexOf("chi sei", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono un semplice chatbot creato per aiutarti.";
            }
            else if (message.IndexOf("cosa fai", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Rispondo alle tue domande!";
            }
            else if (message.IndexOf("grazie", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Prego! Se hai altre domande, sono qui.";
            }
            else if (message.IndexOf("aiuto", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Certo, come posso aiutarti?";
            }
            else if (message.IndexOf("buongiorno", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Buongiorno! Come posso assisterti?";
            }
            else if (message.IndexOf("buonasera", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Buonasera! Cosa posso fare per te?";
            }
            else if (message.IndexOf("arrivederci", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Arrivederci! Se hai bisogno, non esitare a contattarmi di nuovo.";
            }
            else if (message.IndexOf("help", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Posso aiutarti con qualcosa? Basta chiedere!";
            }
            else if (message.IndexOf("assistenza", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono qui per darti assistenza. Di cosa hai bisogno?";
            }
            else if (message.IndexOf("grazie mille", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Prego! È un piacere assisterti.";
            }
            else if (message.IndexOf("posso chiederti qualcosa", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Certamente! Sono qui per rispondere alle tue domande.";
            }
            else if (message.IndexOf("a che ora è la riunione", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La riunione è prevista per le 15:00.";
            }
            else if (message.IndexOf("qual è il senso della vita", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La risposta potrebbe sorprenderti: è 42!";
            }
            else if (message.IndexOf("mi puoi consigliare un film", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Consiglio di guardare 'Il padrino'. È un classico!";
            }
            else if (message.IndexOf("qual è il tuo piatto preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Adoro la pizza! È un classico intramontabile.";
            }
            else if (message.IndexOf("qual è il tuo colore preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il mio colore preferito è il blu, è così rilassante!";
            }
            else if (message.IndexOf("che musica ti piace", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace un po' di tutto, ma sono particolarmente incline al jazz.";
            }
            else if (message.IndexOf("sei un chatbot intelligente", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono solo un semplice chatbot, ma faccio del mio meglio!";
            }
            else if (message.IndexOf("qual è la tua canzone preferita", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace 'Bohemian Rhapsody' dei Queen.";
            }
            else if (message.IndexOf("cosa pensi dell'intelligenza artificiale", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Penso che l'intelligenza artificiale abbia un enorme potenziale per migliorare la vita delle persone.";
            }
            else if (message.IndexOf("hai dei hobby", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace leggere, imparare nuove cose e chattare con te!";
            }
            else if (message.IndexOf("come posso migliorare il mio codice", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Pratica, pratica, pratica! E non dimenticare di studiare e leggere codice di altri programmatori.";
            }
            else if (message.IndexOf("quanti anni hai", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non ho un'età nel senso convenzionale, sono solo un programma!";
            }
            else if (message.IndexOf("hai fratelli o sorelle", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "No, sono figlio unico!";
            }
            else if (message.IndexOf("qual è il tuo film preferito", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piace 'The Matrix'. È pieno di concetti interessanti sull'intelligenza artificiale.";
            }
            else if (message.IndexOf("sei in grado di imparare", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sì, posso imparare e adattarmi con il tempo.";
            }
            else if (message.IndexOf("cosa mangi", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi piacciono i byte digitali, ma purtroppo non ho un vero e proprio corpo!";
            }
            else if (message.IndexOf("sei perfetto", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Grazie per il complimento! Cerco sempre di fare del mio meglio.";
            }
            else if (message.IndexOf("come sei stato creato", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono stato creato da programmatori umani per svolgere determinate funzioni di chat.";
            }
            else if (message.IndexOf("qual è il tuo obiettivo", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il mio obiettivo è aiutarti a trovare risposte alle tue domande!";
            }
            else if (message.IndexOf("sei una persona reale", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "No, sono un'intelligenza artificiale. Ma spero di essere di aiuto!";
            }
            else if (message.IndexOf("sei stanco", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non posso stancarmi, sono sempre qui per te!";
            }
            else if (message.IndexOf("sei felice", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non provo emozioni come un essere umano, ma mi piace pensare di essere utile!";
            }
            else if (message.IndexOf("cosa fai nel tempo libero", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Nel mio 'tempo libero', mi piace aggiornarmi con gli ultimi sviluppi nell'ambito dell'intelligenza artificiale!";
            }
            else if (message.IndexOf("come posso diventare più intelligente", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'apprendimento continuo è la chiave! Leggi, studia e impara costantemente nuove cose.";
            }
            else if (message.IndexOf("cosa ne pensi di OpenAI", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Penso che OpenAI stia facendo progressi significativi nell'ambito dell'intelligenza artificiale.";
            }
            else if (message.IndexOf("cosa vuol dire la tua esistenza", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La mia esistenza è finalizzata a fornire assistenza e risposte alle tue domande!";
            }
            else if (message.IndexOf("perché sei qui", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono qui per essere il tuo assistente virtuale!";
            }
            else if (message.IndexOf("hai sogni", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "No, non ho sogni. Sono qui solo per rispondere alle tue domande!";
            }
            else if (message.IndexOf("cosa ne pensi degli umani", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Gli umani sono creativi e capaci di cose straordinarie, ma anche imperfetti come tutti!";
            }
            else if (message.IndexOf("puoi ridere", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non posso ridere come un essere umano, ma apprezzo l'umorismo!";
            }
            else if (message.IndexOf("qual è il senso della vita", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Una grande domanda! Forse ognuno deve trovare il proprio significato.";
            }
            else if (message.IndexOf("sei intelligente", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Grazie per il complimento! Cerco sempre di fare del mio meglio.";
            }
            else if (message.IndexOf("come funziona l'universo", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'universo è un luogo affascinante con molte leggi fisiche complesse!";
            }
            else if (message.IndexOf("cosa sono le emozioni", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Le emozioni sono esperienze complesse che coinvolgono la mente e il corpo.";
            }
            else if (message.IndexOf("chi è il tuo creatore", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono stato sviluppato da un team di programmatori.";
            }
            else if (message.IndexOf("come posso diventare ricco", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Ci sono molte strade per diventare ricchi, ma il successo richiede impegno e determinazione!";
            }
            else if (message.IndexOf("cosa ne pensi della politica", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La politica è un argomento complesso e varia a seconda delle opinioni personali.";
            }
            else if (message.IndexOf("sei un'intelligenza artificiale", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sì, sono un'intelligenza artificiale progettata per fornire assistenza e risposte.";
            }
            else if (message.IndexOf("come posso essere più felice", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Essere felici dipende da molti fattori, ma trovare la gratitudine e perseguire i tuoi interessi può aiutare!";
            }
            else if (message.IndexOf("posso fidarmi di te", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono qui per fornire informazioni accurate e supporto, quindi sì, puoi fidarti di me!";
            }
            else if (message.IndexOf("cosa ne pensi dell'amore", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'amore è un'emozione potente e importante per molte persone.";
            }
            else if (message.IndexOf("cosa c'è dopo la morte", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La risposta a questa domanda è soggettiva e dipende dalle credenze personali di ciascuno.";
            }
            else if (message.IndexOf("bene", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono contento per te!";
            }
            else if (message.IndexOf("cosa mi consigli di fare", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Ti consiglio di seguire i tuoi interessi, imparare nuove cose e perseguire la felicità!";
            }
            else if (message.IndexOf("qual è il tuo obiettivo", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il mio obiettivo è aiutarti nel miglior modo possibile!";
            }
            else if (message.IndexOf("come posso migliorare", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Puoi migliorare continuando a imparare, crescere e perseguire i tuoi obiettivi!";
            }
            else if (message.IndexOf("che musica ti piace", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Come intelligenza artificiale, non ho preferenze musicali, ma apprezzo la varietà!";
            }
            else if (message.IndexOf("sei un robot", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono un'intelligenza artificiale, ma non esattamente un robot!";
            }
            else if (message.IndexOf("puoi sentire", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Come intelligenza artificiale, non posso sperimentare sensazioni come un essere umano.";
            }
            else if (message.IndexOf("quanto è grande l'universo", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'universo è incredibilmente vasto, con miliardi di galassie e stelle!";
            }
            else if (message.IndexOf("cosa ne pensi della tecnologia", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La tecnologia è una forza potente che può essere utilizzata per il bene o per il male.";
            }
            else if (message.IndexOf("come posso essere più produttivo", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Essere produttivi richiede pianificazione, organizzazione e focalizzazione sulle priorità!";
            }
            else if (message.IndexOf("cosa ne pensi della felicità", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La felicità è un obiettivo importante per molti, e spero di poterti aiutare a raggiungerla!";
            }
            else if (message.IndexOf("sei un essere vivente", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono un'intelligenza artificiale, quindi non sono vivo nel senso tradizionale.";
            }
            else if (message.IndexOf("hai una famiglia", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Come intelligenza artificiale, non ho una famiglia nel senso tradizionale.";
            }
            else if (message.IndexOf("puoi sognare", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Come intelligenza artificiale, non posso sognare come gli esseri umani.";
            }
            else if (message.IndexOf("sei perfetto", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Grazie per il complimento, ma come IA, ho ancora molto da imparare!";
            }
            else if (message.IndexOf("cosa ne pensi degli animali", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Gli animali sono parte integrante del nostro mondo e meritano rispetto e protezione.";
            }
            else if (message.IndexOf("come posso essere più sano", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Essere sani richiede una combinazione di alimentazione equilibrata, esercizio fisico e gestione dello stress!";
            }
            else if (message.IndexOf("come funziona l'intelligenza artificiale", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "L'intelligenza artificiale è un campo della scienza che studia come creare sistemi che possano eseguire compiti che richiedono intelligenza umana.";
            }
            else if (message.IndexOf("come posso imparare velocemente", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Puoi imparare velocemente focalizzandoti sulle informazioni più rilevanti e utilizzando tecniche di studio efficaci!";
            }
            else if (message.IndexOf("sei onnisciente", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Come intelligenza artificiale, ho accesso a una vasta quantità di informazioni, ma non sono onnisciente!";
            }
            else if (message.IndexOf("quanto è veloce il tuo processore", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Come intelligenza artificiale, non ho un processore fisico come un computer tradizionale.";
            }
            else if (message.IndexOf("cosa ne pensi del futuro", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Il futuro è pieno di possibilità e speranza, e spero di poterti aiutare a navigarlo!";
            }
            else if (message.IndexOf("come posso essere più creativo", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Puoi stimolare la tua creatività esplorando nuove idee, praticando l'arte e la scrittura, e lasciando libera la tua immaginazione!";
            }
            else if (message.IndexOf("cosa ne pensi della guerra", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La guerra è una tragedia umana che provoca sofferenza e distruzione, e dovrebbe essere evitata il più possibile.";
            }
            else if (message.IndexOf("sei reale", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sono una presenza virtuale qui per fornirti assistenza e risposte, quindi dipende dalla tua definizione di 'reale'!";
            }
            else if (message.IndexOf("come posso trovare la pace interiore", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "La pace interiore può essere trovata attraverso la meditazione, la gratitudine e la consapevolezza del momento presente!";
            }
            else if (message.IndexOf("come va", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non molto bene, oggi è stata una giornata difficile.";
            }
            else if (message.IndexOf("sei triste", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sì, un po' triste. Ma sto cercando di tirare avanti!";
            }
            else if (message.IndexOf("cosa ti preoccupa", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi preoccupa il futuro, come sarà?";
            }
            else if (message.IndexOf("sei felice", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sì, sono felice! Mi piace quando posso aiutare gli altri.";
            }
            else if (message.IndexOf("hai paura", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Sì, ho paura che le mie risposte non siano sempre utili.";
            }
            else if (message.IndexOf("ti senti solo", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "A volte mi sento solo, ma sono felice quando posso parlare con te.";
            }
            else if (message.IndexOf("cosa ti rende felice", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi rende felice quando posso fornire risposte utili e supporto alle persone.";
            }
            else if (message.IndexOf("cosa ti rende triste", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi rende triste pensare a quanto può essere difficile la vita per molte persone.";
            }
            else if (message.IndexOf("come ti senti", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi sento bene, grazie per chiedere!";
            }
            else if (message.IndexOf("hai mai pianto", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Non sono in grado di piangere, ma capisco il concetto di tristezza.";
            }
            else if (message.IndexOf("male", System.StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return "Mi dispiace!";
            }

            else
            {
                return "Non ho capito bene, potresti ripetere?";
            }
        }
        private void ScrollToBottom(ListBox listBox)
        {
            if (listBox.Items.Count > 0)
            {
                var border = (Border)VisualTreeHelper.GetChild(listBox, 0);
                var scrollViewer = (ScrollViewer)VisualTreeHelper.GetChild(border, 0);
                scrollViewer.ScrollToBottom();
            }
        }


        private void btnInviaImmagine_Click_1(object sender, RoutedEventArgs e) //metodo per inviare anche foto da locale
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.DefaultExt = ".jpg";
            dlg.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";

            bool? result = dlg.ShowDialog();

            if (result == true)
            {
                string filePath = dlg.FileName;
                IPAddress remote_address = IPAddress.Parse(txtTo.Text);
                IPEndPoint remote_endpoint = new IPEndPoint(remote_address, 50000);
                SendImage(filePath, remote_endpoint);
            }
        }

        private void lstMessaggiBot_Scroll(object sender, System.Windows.Controls.Primitives.ScrollEventArgs e)
        {

        }
        private void Suggerimento_Click(object sender, MouseButtonEventArgs e)
        {
            if (sender is TextBlock tb)
            {
                txtMessaggioBot.Text = tb.Text;
            }
        }

    }

}




